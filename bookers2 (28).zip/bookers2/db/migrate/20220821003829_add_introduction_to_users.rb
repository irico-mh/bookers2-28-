class AddIntroductionToUsers < ActiveRecord::Migration[5.2]
  
end
