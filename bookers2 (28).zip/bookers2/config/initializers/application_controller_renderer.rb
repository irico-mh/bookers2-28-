# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'fd9f4701e217a661eccd26fc70f952daa1a325219bca2b280bd50c4f83b123d5a5086e9e6b17be8991c399d54f052a4150f472ec430bfa8b3e4528c7a0d4257b'
Refile.secret_key = 'e14a86c96e2cedfa69c45a1aaedaf3c1fbe0e3c9465e1e72073957f0ebaf4e4d44e253034c6b60643646e76436053b236b67b7ac24d2c73dfcaee42699b7a6a9'
